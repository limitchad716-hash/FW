# FW – Floating Windows
1. Push this folder to a GitHub repo (branch `main`).
2. Actions tab -> "Build FW APK" -> download artifact `FW-apk` -> install app-debug.apk.
3. Open FW -> allow overlay + mic + notifications -> START FLOATING WINDOWS.
