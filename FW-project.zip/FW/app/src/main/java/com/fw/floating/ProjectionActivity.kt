package com.fw.floating

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast

class ProjectionActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (RecorderService.isRecording) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            finish(); return
        }
        val mgr = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mgr.createScreenCaptureIntent(), 7)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 7 && res == RESULT_OK && d != null) {
            startForegroundService(Intent(this, RecorderService::class.java)
                .setAction(RecorderService.ACTION_START).putExtra("code", res).putExtra("data", d))
        } else Toast.makeText(this, "Hindi na-allow ang screen record", Toast.LENGTH_SHORT).show()
        finish()
        overridePendingTransition(0, 0)
    }
}
